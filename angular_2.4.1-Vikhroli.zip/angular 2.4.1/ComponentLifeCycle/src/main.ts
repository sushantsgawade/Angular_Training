import { Component,enableProdMode,NgModule,OnInit,OnDestroy } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

@Component({
  selector: 'on-init',
  template: "<div>Init/Destroy</div>"
})
class DirectiveComponent implements OnInit,OnDestroy{
  constructor(){
    console.log("DirectiveComponent : Constructor Invoked");
  }
  ngOnInit(): void{
    console.log("DirectiveComponent : OnInit Executed");
  }
  ngOnDestroy(): void{
    console.log("DirectiveComponent : OnDestroy Executed");
  }
 }

@Component({
  selector: 'my-app',
  template: `<h1>LifeCycle hooks</h1>
  <h4>OnInit and OnDestroy</h4>
  <button (click)="toggle()">Toggle</button>
  <hr/>
  <on-init *ngIf="display"></on-init>`
})
export class AppComponent{
	display:boolean;
	constructor(){
		this.display = true;
	}
	toggle(){
		this.display = !this.display;		
	}
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ AppComponent,DirectiveComponent ],
	bootstrap:[ AppComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  
  