import { Component } from '@angular/core';

@Component({
    template:`
        <div>
            <h1>Contact Page</h1>
        </div>` 
})
export class ContactComponent{} 