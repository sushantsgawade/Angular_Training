import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule, Inject , Injectable, OnInit} from '@angular/core';

class Employee{
    id:number;
    name:string;
    constructor(id:number,name:string){
        this.id = id;
        this.name = name;
    }

}

@Injectable()
class EmployeeService{
    getAllEmployees():Employee[]{
        return [
           new Employee(1,"Karthik"),
           new Employee(2,"Ganesh"),
        ]
    }
}


@Component({
    selector:'my-app',
    template:`<div>
        <h1>Service Demo</h1>
        <hr/>
        <ul>
            <li *ngFor="let employee of employees">{{employee.id+" "+employee.name}}</li>
        </ul>
    </div>`
})
class AppComponent implements OnInit{
   employees:Employee[];

   constructor(@Inject(EmployeeService) private serviceObj:EmployeeService,@Inject('AddNumbers') add:Function, @Inject('COMPANY_NAME') companyName:string){
        console.log(add(5,6));
        console.log(companyName);
    }

    ngOnInit(): void{
        this.employees = this.serviceObj.getAllEmployees();
    }
 }

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent ],
    bootstrap:[ AppComponent ],
    providers:[/*Class Provider*/EmployeeService, /*Factory Provider*/{
        provide:'AddNumbers', 
        useFactory:function(){
            return function(a:number,b:number):number{
                return a+b;
            }
        }
    },/*Value Provider*/{ provide:'COMPANY_NAME',useValue:'CAPGEMINI'}]
})
class AppModule{}
platformBrowserDynamic().bootstrapModule(AppModule);
