import 'rxjs/Rx'; 
import { Observable } from 'rxjs/Observable';
import {Subscriber } from 'rxjs/Subscriber';

/*
(function(){
    Observable.of(1,3).subscribe(val=>{console.log("Of : "+val)});
    Observable.range(1,3).subscribe(val=>{console.log("Range : "+val)});
    Observable.interval(10).take(2).subscribe(val=>{console.log("Interval : "+val)});
    
    //Mathematical Operators
    Observable.from([17,2,31,4,5]).max().subscribe(val=>{console.log("Max : "+val)});
    Observable.from([1,2,31,-4,5]).min().subscribe(val=>{console.log("Min : "+val)});
    Observable.from([1,2,31,4,5]).count().subscribe(val=>{console.log("Count : "+val)});
    Observable.from([1,2,3,4,5]).reduce((x,y)=>x*y).subscribe(val=>{console.log("Reduce : "+val)});
    
    //Boolean Operators 
    Observable.from([66,2,32,4,58]).every(val=>val%2===0).subscribe(val=>{console.log("Every : "+val)});
    Observable.from([66,2,32,41,58]).sequenceEqual(Observable.from([66,2,32,41,58])).subscribe(val=>{console.log("Sequence : "+val)});
    
   // Filtering Operators 
    Observable.from([1,2,5,2,5]).distinct().subscribe(val=>{console.log("Distinct : "+val)});
    Observable.from([1,2,5,2,7]).elementAt(2).subscribe(val=>{console.log("ElementAt : "+val)});
    Observable.from([32,75,21,44,55]).filter(x=>x%2==0).subscribe(val=>{console.log("Filter : "+val)});
    Observable.from([31,75,21,44,55]).find(x=>x%2==0).subscribe(val=>{console.log("Find : "+val)});
    Observable.from([32,75,21,44,55]).first().subscribe(val=>{console.log("First : "+val)});
    Observable.from([32,75,21,44,55]).skip(4).subscribe(val=>{console.log("Skip : "+val)});
    Observable.from([32,75,21,44,55]).take(2).subscribe(val=>{console.log("Take : "+val)});
    Observable.from([{id:1,name:'Karthik'},{id:2,name:'Ganesh'}]).pluck('name').subscribe(val=>{console.log("Pluck : "+val)});
    
   //Transforming Operators 
    Observable.from([22,47,88]).delay(10).subscribe(val=>{console.log("Delay : "+val)});
    Observable.from([22,47,88]).findIndex(x=>x>40).subscribe(val=>{console.log("FindIndex : "+val)});
    Observable.from([1,2,3]).map(x=>x*2).subscribe(val=>{console.log("Map : "+val)});
    
   //Combining Operators
    Observable.from([1,2,3]).concat(Observable.from([4,5])).subscribe(val=>{console.log("Concat : "+val)});
    Observable.interval(2000).take(2).merge(Observable.interval(1000).take(2)).subscribe(val=>{console.log("Merge : "+val)});
    
    Observable.of('Hi').subscribe(v=>{Observable.of(v+' Everyone').subscribe(v=>{console.log(v)})});
    //Recommended
    Observable.of('Hi').mergeMap(v=>{return Observable.of(v+' Everyone')}).subscribe(v=>{console.log(v)});
})();

(function(){
    var source = Observable.interval(1000).map(num=>['1','2','3','A','4','5','6'][num]);
    var result = source.map(x=>parseInt(x)).filter(x=> !isNaN(x));
    result.subscribe(x=>console.log(x));
})();

(function(){
  var btnStream =  Observable.fromEvent(document.querySelector('#btn'),'click');
  btnStream.subscribe((e)=>{
      document.querySelector("#target").innerHTML = "Clicked";
  })
})();

(function(){
    var source = new Observable((observer:Subscriber<number>)=>{
       var counter = 1;
        var id = setInterval(function(){
            try{
                if(counter <= 5){
                    observer.next(counter);
                    counter += 1;
                    if(counter==5) throw 'Error Occured';
                }
                else{
                    observer.complete();
                }
            }catch(error){
                observer.error(error);
            }
        },1000);
        
        return function(){
            console.log('disposal Called')
            clearInterval(id);
        }
    });
    source.subscribe(value=>console.log(value),error=>console.log("Error : "+error),()=>console.log("completed"));
})();
*/

(function(){

   /* let numbers = [54,65,87,23,76];
   var observableObj:Observable<number> = Observable.from(numbers);

  observableObj.subscribe((v:number)=>{
       console.log("Number Retrieved : "+v);
   },(err)=>{
       console.log("Error Occured : "+err);
   },()=>{
       console.log("Completed");
   });*/


/*  var observableObj:Observable<MouseEvent> =  Observable.fromEvent(document.querySelector('#source'),"mousemove");

  observableObj.subscribe(function(response:MouseEvent){
      document.querySelector('#target').innerHTML = response.screenX+" : "+response.screenY;
  });*/

 /* var promise1 = Promise.resolve("Promise 1 Resolved");
  var promise2 = Promise.resolve("Promise 2 Resolved");
  var promise3 = Promise.resolve("Promise 3 Resolved");
  var promise4 = Promise.resolve("Promise 4 Resolved");
  var promiseObj = Promise.all([promise1,promise2,promise3,promise4]);

  var observaleObj = Observable.fromPromise(promiseObj);

  observaleObj.subscribe((res)=>{
      res.forEach(function(data){
          console.log("Success : "+data);
      });
  });*/

 /*setInterval(()=>{
     console.log(Math.random());
 },1000);*/

 var observableObj = new Observable((observer:Subscriber<number>)=>{
     setInterval(()=>{
         var randomValue = Math.random();
         if(randomValue > 0.5)
            observer.next(randomValue);
        else if(randomValue < 0.1)
            observer.error("Error Occured : "+randomValue);
        else
            observer.complete();
     },1000);
 });

observableObj.subscribe((v)=>{
    console.log("Number : "+ v);
},(err)=>{
    console.log(err);
},()=>{
    console.log("Process Completed");
})


})();