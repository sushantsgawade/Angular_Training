import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule, Input,Output,EventEmitter } from '@angular/core';

interface Employee{
    id:number,
    name:string
}

@Component({
    selector:'inner-app',
    template:`<div class="custom">
        <h1>Inner Component</h1>
        <div class="well">
            <span>{{ 'Id : ' +employee["id"]+" Name : "+employee["name"] }}</span>
         
        </div>
        <button class="btn btn-primary" (click)="OnMyClick()">Send Message</button>
    </div>`,
    styles:['.custom { border:1px solid black; background:powderblue; padding:20px; margin:20px}']
})
class AppInnerComponent{
    innerMessage:string;
    @Input('recievedEmployee') employee :Employee;
    @Output() myclick = new EventEmitter();
   constructor(){
       this.innerMessage = "Message from AppInnerComponent";
   }
   OnMyClick():void{
       this.employee.id = 707224;
       this.employee.name = "Latha";
       this.myclick.emit(this.innerMessage);
   }

}

@Component({
    selector:'my-app',
    template:`<div class="custom">
        <h1>Outer Component - {{ outerMessage }}</h1>
        <div class="well">
            <span>{{ 'Id : ' +employee["id"]+" Name : "+employee["name"] }}</span><br/>
               <span>{{ 'Recieved from Child : '+recievedMesage }}</span>
        </div>
        <inner-app [recievedEmployee]="employee" (myclick)="getModifiedEmployee($event)"></inner-app>
    </div>`,
    styles:['.custom { border:1px solid black; background:aliceblue; padding:20px; margin:20px}']
})
class AppComponent{
   outerMessage:string;
   recievedMesage:string;
   employee:Employee;
   constructor(){
       this.outerMessage = "Message from AppComponent";
       this.employee = { id:714709, name:'Karthik'};
   }
   getModifiedEmployee(e:string){
       this.recievedMesage = e;
   }
}

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent, AppInnerComponent ],
    bootstrap:[ AppComponent ]
})
class AppModule{}
platformBrowserDynamic().bootstrapModule(AppModule);
