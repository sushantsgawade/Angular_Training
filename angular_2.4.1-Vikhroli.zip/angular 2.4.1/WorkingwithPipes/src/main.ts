import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule,Pipe, PipeTransform } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';

@Pipe({
    name:'changecase'
})
class ChangeCase implements PipeTransform{
     transform(value: string, toWhichCase: string):string {
         let data = value;
         if(toWhichCase=="upper")
             data = data.toUpperCase();
         return data;
   }
}

@Pipe({
    name:'filterArray'
})
class FilterFromArray implements PipeTransform{
     transform(numbers: number[], filterType: string):number[] {
         let evenNumbers:number[]=[];
         let oddNumbers:number[]=[];
         
         numbers.forEach((item)=>{
             if(item % 2 == 0)
                evenNumbers.push(item);
            else
                oddNumbers.push(item);
         });
         if(filterType == "even")
            return evenNumbers;
        else
            return oddNumbers;
   }
}

@Component({
    selector:'my-app',
    template:`<div>
        <h1>Built in Pipes</h1>
        <hr/>
        <p>{{ 'capgemini' | uppercase }}</p>
        <p>{{ 'INDIA' | lowercase }}</p>
        <p>{{ 200 | currency:"EUR" }}</p>
        <p>{{ today | date:"EEEE, dd MMMM yyyy" }}</p>
        <p>{{ {id:1,name:'Karthik'} | json }}</p>
        <p>{{ observer | async }}</p>
        <hr/>
        <h2>Custom Pipes</h2>
        <p>{{ 'Karthik' | changecase:'upper' }}</p>
        <p>{{ [1,2,3,4,5,6,7,8,9,10] | filterArray:'odd' }}</p>
    </div>`
})
class AppComponent{
    today:Date = new Date();
    observer:Observable<number> = Observable.interval(1000);
}

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent, ChangeCase, FilterFromArray ],
    bootstrap:[ AppComponent ]
})
export class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
