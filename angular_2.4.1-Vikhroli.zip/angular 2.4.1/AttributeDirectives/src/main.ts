import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule } from '@angular/core';
import { NgClass } from '@angular/common';



@Component({
    selector:'my-app',
    template:`<div>
        <h1>Attribute Directives</h1>
        <hr/>
        <h2>ngStyle - Attribute Directive</h2>
        <h3 [ngStyle]="{'font-style': style, 'font-weight': weight, 'font-size':size}">Change style of this text!</h3>
        <hr/>
        <label><input type="checkbox" (change)="changeStyle($event)">Italic</label>
        <label><input type="checkbox" (change)="changeWeight($event)">Bold</label>
        <label>Size: <input type="text" [value]="size" (change)="size=$event.target.value" /></label>  
         <h2>ngClass - Attribute Directive</h2>
         <button (click)="isOn=!isOn" [ngClass]="{'active': isOn}">Click Me!</button>
    </div>`,
    styles: ['.active { background-color: yellow;}']
})

class AppComponent{
    style:string = 'normal';
	weight:string = 'normal';
	size:string='20px';
    isOn:boolean = true;
    changeStyle($event: any){
		this.style = $event.target.checked ? 'italic' : 'normal';
	}
	changeWeight($event: any) {
        this.weight = $event.target.checked ? 'bold' : 'normal';
   }
 }

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent ],
    bootstrap:[ AppComponent ]
})
class AppModule{}
platformBrowserDynamic().bootstrapModule(AppModule);
