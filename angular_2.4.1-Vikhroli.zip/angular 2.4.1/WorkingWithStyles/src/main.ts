import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule  } from '@angular/platform-browser';
import { NgModule, Component, enableProdMode } from '@angular/core';


@Component({
    selector:'my-app',
    template:`
    <link href="./src/main.css" rel="stylesheet">
    <style>
        .sty1{ color:blue }
    </style>
    <div>
        <p style="color:red">Inline Style</p>
        <p class="sty2">Inline Using styles metadata</p>
        <p class="sty1">Internal Style</p>
        <p class="sty3">External Style</p>
        <p class="sty4">Styles Url Style</p>
    </div>`,
    styles:['.sty2{color:brown}'],
    styleUrls:['./src/main.styleurl.css']
 })
class AppComponent{}

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent ],
    bootstrap:[ AppComponent ]
})
class AppModule{}

enableProdMode();
platformBrowserDynamic().bootstrapModule(AppModule);