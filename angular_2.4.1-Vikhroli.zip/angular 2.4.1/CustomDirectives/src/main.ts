import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule,Directive,HostBinding, HostListener } from '@angular/core';

@Directive({
    selector:'[my-directive]'
})
class MyDirective{
    @HostBinding('attr.role') role:string = "guest";
    
    @HostListener('click',['$event'])
    changeRole(e:any):void{
        this.role = this.role == "guest"?"admin":"guest";
        e.target.textContent = this.role;
    }
}

@Component({
    selector:'my-app',
    template:`<div>
        <h1>Custom Directive</h1>
        <hr/>
        <button my-directive>Button-1</button>
        <button>Button-2</button>
        <div my-directive>Testing-Div</div>
    </div>`
})
class AppComponent{
  
}

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent, MyDirective ],
    bootstrap:[ AppComponent ]
})
export class AppModule{}



platformBrowserDynamic().bootstrapModule(AppModule);
