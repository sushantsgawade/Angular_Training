import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
 import { FormsModule } from '@angular/forms';
import { Component, NgModule } from '@angular/core';

@Component({
    selector:'my-app',
    template:`<div>
        <h2>One Way Binding</h2>
        <p>{{ greet }}</p>
        <hr/>
        <h2>Property Binding</h2>
        <p [innerText]="companyName"></p>
        <h2>Event Binding</h2>
        <div>
            <button class="btn btn-primary" (click)="getCurrentTime()" >Get Time</button>
            <p>{{ time }}</p>
        </div>
        <h2>Two Way Binding</h2>
        <input type="text" [(ngModel)]="data"/>
        <small>{{ data }}</small>
    </div>`
})
class AppComponent{
    greet:string = "Welcome";
    companyName:string="Capgemini";
    time:string = new Date().toLocaleTimeString();
    data:string = "Initial Value";

    getCurrentTime():void{
      this.time = new Date().toLocaleTimeString();
    }
}

@NgModule({
    imports:[ BrowserModule, FormsModule ],
    declarations:[ AppComponent ],
    bootstrap:[ AppComponent ]
})
class AppModule{}
platformBrowserDynamic().bootstrapModule(AppModule);
