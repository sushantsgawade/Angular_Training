import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule } from '@angular/core';
import { NgSwitch, NgSwitchCase, NgSwitchDefault, NgStyle, NgClass } from '@angular/common';


interface Employee{
    id:number,
    name:string
}

@Component({
    selector:'my-app',
    template:`<div>
        <h1>Structural Directives</h1>
        <hr/>
        <h2>ngIf - Structural Directive</h2>
        <button (click)="ShowOrHide()">{{ displayStatus==true?"Hide":"Show" }}</button>
        <div *ngIf="displayStatus">It will be shown</div>
        <hr/>
        <h2>ngFor - Structural Directive</h2>
        <ul>
            <li *ngFor="let city of cities; let counter=index">{{ counter +":"+ city }}</li>
        </ul>
        <div>
            <span>Employee : </span>
            <select>
                <option *ngFor="let employee of employees" [value]="employee.id">{{ employee.name }}</option>
            </select>
        </div>
         <hr/>
        <h2>ngSwitch - Structural Directive</h2>
        <button (click)="IncrementValue()">Increment Value </button>
        <div [ngSwitch]="value">
             <div *ngSwitchCase=0>Zero</div>     
             <div *ngSwitchCase=1>One</div>
             <div *ngSwitchCase=2>Two</div>
             <div *ngSwitchDefault>Not Supported</div>
        </div>
       
    </div>`
})

class AppComponent{ 
    displayStatus:boolean = false;
    cities:string[] = ["Bangalore","Chennai","Mumbai"];
    value:number = 0;
    employees:Employee[] = [{id:1,name:'Ganesh'},{id:2,name:'Abishek'},{id:3,name:'Anil'}]
    ShowOrHide():void{
        this.displayStatus  = !this.displayStatus;
    }
    IncrementValue():void{
        this.value++;
    }
 }

@NgModule({
    imports:[ BrowserModule ],
    declarations:[ AppComponent ],
    bootstrap:[ AppComponent ]
})
class AppModule{}
platformBrowserDynamic().bootstrapModule(AppModule);
